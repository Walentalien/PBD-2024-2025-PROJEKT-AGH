INSERT INTO Languages (LanguageID, LanguageName)
VALUES 
(1, 'polski'),
(2, 'angielski'),
(3, 'niemiecki'),
(4, 'francuski'),
(5, 'hiszpa�ski'),
(6, 'japo�ski'),
(7, 'czeski'),
(8, 'ukrai�ski'),
(9, 'rosyjski'),
(10, 'chi�ski')

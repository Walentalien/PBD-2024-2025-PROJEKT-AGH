

INSERT INTO Translators (TranslatorID, FirstName, LastName, Address, CityID, BirthDate, HireDate, Email, PhoneNumber)
VALUES 
(1,'Artur','Warta','Nowohucka 24',1,'1999-07-13','2024-03-05','wartur@gmail.com','559558557'),
(2,'Adam','Wawrzy�ski','D�uga 5',9,'1967-01-09','2024-03-05','wawrzynskiadas@gmail.com','123123123'),
(3,'Marta','Ma�ysa','Kr�tka 2',10,'1978-03-12','2024-03-05','mmalysa@gmail.com','555111333'),
(4,'Alicja','Ba�enkowska','Kolorowa 7',15,'1969-05-17','2024-04-25','alabal@gmail.com','223344789')
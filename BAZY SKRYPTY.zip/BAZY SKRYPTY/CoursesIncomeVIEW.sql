CREATE VIEW CoursesIncome AS

SELECT c.CourseID, CourseTitle, SUM(PaidValue) AS Income
FROM OrderDetails AS od 
INNER JOIN OrderedCourses AS oc ON od.ProductID = oc.ProductID
INNER JOIN Courses AS c ON c.CourseID = oc.CourseID
GROUP BY c.CourseID, CourseTitle







--select * from OrderedCourses
--select * from Courses

INSERT OrderedCourses (ProductID, CourseID)
VALUES
/*COURSES PAID*/
(14,1),
(15,5),
(16,3),
(17,1),
(18,5),

/*COURSES NOT PAID*/
(19,2)

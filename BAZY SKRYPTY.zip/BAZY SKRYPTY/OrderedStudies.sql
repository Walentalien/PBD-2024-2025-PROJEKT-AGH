
INSERT OrderedStudies (ProductID, StudyID)
VALUES
(22,	1),
(23,	2)
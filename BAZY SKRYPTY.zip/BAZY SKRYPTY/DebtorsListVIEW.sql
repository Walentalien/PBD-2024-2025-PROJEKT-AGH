CREATE VIEW DebtorsList AS

SELECT s.StudentID AS DebtorID, (s.FirstName + ' ' + s.LastName) AS Debtor, o.OrderID, od.ProductID,
WebinarPrice AS Price, PaidValue, (WebinarPrice - PaidValue) AS Debt, s.Email, s.PhoneNumber
FROM Orders AS o
INNER JOIN OrderDetails AS od ON o.OrderID = od.OrderID
INNER JOIN OrderedWebinars AS ow ON od.ProductID = ow.ProductID
INNER JOIN Webinars AS w ON w.WebinarID = ow.WebinarID
INNER JOIN Students AS s ON o.StudentID = s.StudentID
WHERE WebinarPrice - PaidValue <> 0

UNION 

SELECT s.StudentID AS DebtorID, (s.FirstName + ' ' + s.LastName) AS Debtor, o.OrderID, od.ProductID,  
CoursePrice AS Price, PaidValue, (CoursePrice - PaidValue) AS Debt, s.Email, s.PhoneNumber
FROM Orders AS o
INNER JOIN OrderDetails AS od ON o.OrderID = od.OrderID
INNER JOIN OrderedCourses AS oc ON od.ProductID = oc.ProductID
INNER JOIN Courses AS c ON c.CourseID = oc.CourseID
INNER JOIN Students AS s ON o.StudentID = s.StudentID
WHERE CoursePrice - PaidValue <> 0

UNION

SELECT s.StudentID AS DebtorID, (s.FirstName + ' ' + s.LastName) AS Debtor, o.OrderID, od.ProductID,  
(SUM(MeetingPrice) + AdvancePaymentPrice) AS Price, PaidValue, 
(SUM(MeetingPrice) + AdvancePaymentPrice - PaidValue) AS Debt, s.Email, s.PhoneNumber
FROM Orders AS o
INNER JOIN OrderDetails AS od ON o.OrderID = od.OrderID
INNER JOIN OrderedStudies AS os ON od.ProductID = os.ProductID
INNER JOIN Studies AS st ON st.StudyID = os.StudyID
INNER JOIN Students AS s ON o.StudentID = s.StudentID
INNER JOIN Subjects AS sbj ON sbj.StudyID = st.StudyID
INNER JOIN StudyMeetings AS sm ON sm.SubjectID = sbj.SubjectID
GROUP BY s.StudentID, s.FirstName, s.LastName, o.OrderID, od.ProductID, PaidValue, s.Email, s.PhoneNumber, AdvancePaymentPrice
HAVING SUM(MeetingPrice) + AdvancePaymentPrice - PaidValue <> 0

UNION

SELECT s.StudentID AS DebtorID, (s.FirstName + ' ' + s.LastName) AS Debtor, o.OrderID, od.ProductID,  
GuestMeetingPrice AS Price, PaidValue, (GuestMeetingPrice - PaidValue) AS Debt, s.Email, s.PhoneNumber
FROM Orders AS o
INNER JOIN OrderDetails AS od ON o.OrderID = od.OrderID
INNER JOIN OrderedStudyMeetings AS osm ON od.ProductID = osm.ProductID
INNER JOIN StudyMeetings AS sm ON sm.StudyMeetingID = osm.StudyMeetingID
INNER JOIN Students AS s ON o.StudentID = s.StudentID
WHERE GuestMeetingPrice - PaidValue <> 0







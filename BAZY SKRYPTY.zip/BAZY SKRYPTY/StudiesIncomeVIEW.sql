CREATE VIEW StudiesIncome AS

SELECT u.StudyID, u.StudyTitle, SUM(u.Income) AS Income FROM
(SELECT * FROM NotEnrolledStudiesIncome
UNION
SELECT * FROM EnrolledStudiesIncome) AS u
GROUP BY u.StudyID, u.StudyTitle




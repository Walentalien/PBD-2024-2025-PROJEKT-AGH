CREATE VIEW FutureStudies AS

SELECT StudyMeetingID, MeetingTitle, sm.MeetingDate 
FROM StudyMeetings AS sm
WHERE sm.MeetingDate > GETDATE();





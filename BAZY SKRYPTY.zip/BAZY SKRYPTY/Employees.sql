--select * from Employees

-- usunieto secondname
--ALTER TABLE Employees
--DROP COLUMN SecondName;

-- wykorzystano: https://www.bestrandoms.com/random-address do generowania adres�w
--INSERT INTO Employees (EmployeeID, FirstName, LastName, Address, CityID, BirthDate, HireDate, Email, PhoneNumber, EmployeeFunctionID)
--VALUES 
--(1, 'Agnieszka', 'Ciepa�', '��kowa 26', 1, '1974-01-05', '2024-01-24', 'aciepal@gmail.com', '123259914', 2),
--(2, 'Anna', 'Mura�ska', 'Gda�ska 19', 1, '1955-02-09', '2024-01-24', 'amuran@gmail.com', '122259914', 2),
--(3, 'Jakub', 'Wolny', 'Brodnicka 27', 1, '1966-03-10', '2024-01-24', 'kubawolny@gmail.com', '112259914', 1),
--(4, 'Andrzej', 'Ciekawski', 'Pi�sudskiego 26', 3, '1977-04-11', '2024-01-24', 'aciekawski@gmail.com', '555259914', 1),
--(5, 'Rados�aw', 'Kuta', 'Dojazdowa 100', 2, '1983-05-24', '2024-01-25', 'kutaandrzej@gmail.com', '667259914', 1),
--(6, 'Marek', 'Skwarek', 'Przyjacielska 41', 5, '1988-06-24', '2024-01-25', 'skwarek@gmail.com', '771259914', 1),
--(7, 'Jaros�aw', 'Ogarek', 'Kar�owicza Mieczys�awa 33', 8, '1990-07-25', '2024-02-14', 'jogarek@gmail.com', '866259914', 1),
--(8, 'Krzysztof', 'Ksi��ek', 'W�adys�awa IV 93', 10, '1971-08-26', '2024-02-14', 'kksiazek@gmail.com', '661159914', 1),

--(9, 'Jakob', 'Sikora', 'Velk� pr�hon 1384', 32, '1967-09-27', '2024-02-14', 'jakob.sikora@gmail.com', '230259914', 1),
--(10, 'John', 'Smith', '22 Shore Street', 41, '1964-10-28', '2024-02-14', 'johnsmith64@gmail.com', '990259914', 1),
--(11, 'Andrew', 'Johnson', '203 Armstrong Ave', 44, '1975-11-29', '2024-02-14', 'ajohnson@gmail.com', '888599142', 1),


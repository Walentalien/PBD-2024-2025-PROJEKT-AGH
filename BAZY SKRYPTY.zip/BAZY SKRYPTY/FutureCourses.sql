CREATE VIEW FutureCourses AS

SELECT ModuleID, ModuleTitle, cm.ModuleDate
FROM CourseModules AS cm
WHERE cm.ModuleDate > GETDATE();





--select * from SubjectParticipants
--select * from Subjects
/*
study, student
1 20
subject
1
2
3

2 21
18
19
20
*/
INSERT INTO SubjectParticipants (SubjectID, StudentID, SubjectGrade)
VALUES

(1,20,51),
(2,20,77),
(3,20,89),

(18,21,34),
(19,21,67),
(20,21,92)


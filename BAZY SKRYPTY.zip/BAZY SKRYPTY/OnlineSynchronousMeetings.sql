INSERT INTO OnlineSynchronousMeetings (StudyMeetingID, MeetingLink, RecordingLink)
VALUES
(21, '<meeting link>', '<recording link>'),
(22, '<meeting link>', '<recording link>'),
(23, '<meeting link>', '<recording link>'),
(24, '<meeting link>', '<recording link>'),
(25, '<meeting link>', '<recording link>'),



(36, '<meeting link>', '<recording link>'),
(37, '<meeting link>', '<recording link>'),
(38, '<meeting link>', '<recording link>'),
(39, '<meeting link>', '<recording link>'),
(40, '<meeting link>', '<recording link>'),
(41, '<meeting link>', '<recording link>'),
(42, '<meeting link>', '<recording link>'),
(43, '<meeting link>', '<recording link>'),
(44, '<meeting link>', '<recording link>'),
(45, '<meeting link>', '<recording link>')

/*
SELECT * FROM Internship

SELECT * FROM InternshipPresence

SELECT * FROM OrderedStudies AS os
INNER JOIN OrderDetails AS od ON os.ProductID = od.ProductID
INNER JOIN Orders As o ON o.OrderID = od.OrderID
*/

INSERT INTO InternshipPresence (InternshipID, StudentID, Presence)
VALUES
(1,20,1),
(2,21,1)

/*
study 1 student 20
2 21
*/
CREATE VIEW EnrolledStudiesIncome AS

SELECT s.StudyID, StudyTitle, SUM(PaidValue) AS Income
FROM OrderDetails AS od 
INNER JOIN OrderedStudies AS os ON od.ProductID = os.ProductID
INNER JOIN Studies AS s ON s.StudyID = os.StudyID
GROUP BY s.StudyID, StudyTitle



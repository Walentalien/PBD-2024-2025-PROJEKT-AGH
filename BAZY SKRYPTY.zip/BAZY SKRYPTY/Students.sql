--SELECT * FROM Students

-- dodano PostalCode
--ALTER TABLE Students
--ADD PostalCode nvarchar(20) NOT NULL; 

INSERT INTO Students (StudentID, FirstName, LastName, Address, CityID, BirthDate, Email, PhoneNumber, PostalCode)
VALUES 
(1,'Jakub','Nowak','Mickiewicza Adama 22',1,'2005-01-24','jnowak@gmail.com','810259914','31-555'),
(2,'Adam','Nowak','S�owackiego Juliusza 54',1,'2005-01-22','anowak@gmail.com','326375453','30-342'),
(3,'Rafa�','Kowalski','Koszykarska 34',1,'2001-02-24','rkow@gmail.com','123456789','30-123'),
(4,'Jan','Kowal','Krokusowa 65',1,'2004-06-01','jankow@gmail.com','354765423','30-321'),
(5,'Jakub','Nowowiejski','Podhala�ska 87',1,'2003-08-02','jaknowow@gmail.com','345876123','30-345'),
(6,'Marek','Wi�niewski','Kobierzy�ska 97',1,'2005-06-03','marco1@gmail.com','345876121','30-432'),
(7,'Zofia','W�jcik','Alba�ska 34',1,'1997-07-04','zofia.wojcik@gmail.com','345876120','30-654'),
(8,'Maja','Kami�ska','Batorego Stefana 88',1,'1999-02-05','mkaminska@gmail.com','345876129','30-987'),
(9,'Andrzej','Lewandowski','Centralna 73',1,'2002-03-06','alewandowski@gmail.com','500123550','30-342'),
(10,'Jan','Zieli�ski','Dziewiarzy 4',1,'2000-04-07','janzielinski@gmail.com','345446321','30-122'),
(11,'Wiktor','Kowalski','Farmaceut�w 22',1,'2003-05-08','wiktorkowalski@gmail.com','500123551','30-323'),
(12,'Oliwier','Mleczko','Genera�a D�ugoszowskiego Boles�awa 124',1,'1995-04-09','olimleczko@interia.eu','500123552','30-198'),
(13,'Andrzej','Szyma�ski','Go��bia',1,'2004-06-10','andrewszymanski@gmail.com','500123553','31-111'),
(14,'Jan','Mazur','Lajkonika 3',1,'2004-07-11','jmazur@interia.eu','500123554','31-098'),
(15,'Agnieszka','Piotrowska','Wlotowa 65',1,'2004-08-17','agapiotr@gmail.com','500123555','31-004'),
(16,'Maria','Grabowska','Malborska 12',1,'2006-09-16','mgrabowsska@gmail.com','500123556','31-232'),
(17,'Emil','Wo�niak','Meissnera Janusza',1,'2002-11-14','ewozniak@interia.eu','500123557','31-543'),
(18,'Aleksandra','D�browska','Nazareta�ska 45',2,'2000-12-22','oladabrowska@wp.pl','500123558','12-123'),
(19,'Dominika','Dobrowolska','Niebieska 1',2,'2000-11-21','ddobro@interia.eu','500123559','43-654'),
(20,'Adrian','Kania','Obozowa 111',3,'2001-01-20','adixd@interia.pl','500123111','54-383'),
(21,'Aleksandra','Mrzyg��d','Swaro�yca 31',4,'2001-01-04','amrzyglod@gmail.com','500123222','77-134'),
(22,'Ilya','Melnyk','Kreschatyk 513',33,'2005-11-19','iilyamm@gmail.com','503451622','68301'),
(23,'Artyom','Szewczenko','Antonowicza 432',34,'2004-12-18','artsch@gmail.com','400123222','77890'),
(24,'Wasyl','Kowalenko','Kruhova 23',35,'2006-03-05','wasilkoval@gmail.com','300123222','53478')

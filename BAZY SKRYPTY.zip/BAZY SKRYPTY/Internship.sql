INSERT INTO Internship (InternshipID, StudyID, StartDate)
VALUES 
(1, 1, '2025-01-08'),
(2, 2, '2025-01-10')
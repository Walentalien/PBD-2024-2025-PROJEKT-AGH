--Select * from CourseModules

INSERT INTO OnlineAsynchronousModules (ModuleID, VideoLink)
VALUES 
(38, '<link>'),
(39, '<link>'),
(40, '<link>'),
(41, '<link>'),
(42, '<link>'),
(43, '<link>'),
(44, '<link>'),
(45, '<link>')
INSERT INTO Rooms (RoomID, RoomCapacity)
VALUES 
(1, 30),
(2, 20),
(3, 30),
(4, 30),
(5, 100),
(6, 200),
(7, 250),
(8, 50),
(9, 30),
(10, 30)

/*

select * from CourseParticipants

select * from OrderedCourses


select * from OrderDetails AS od
INNER JOIN OrderedCourses AS oc ON od.ProductID = oc.ProductID
INNER JOIN Orders AS o ON o.OrderID = od.OrderID
*/
/*
product course student
(14 ,	 1 ,  8	),
(15 ,	 5 ,  12	),
(16	,3	,3	),
(17	,1,	18	),
(18	,5,	15	),
(19	,2,	24	)
*/

INSERT INTO CourseParticipants(CourseID, StudentID)
VALUES 

( 1 ,  8	),
(5 ,  12	),
(3	,3	),
(1,	18	),
(5,	15	),
(2,	24	)
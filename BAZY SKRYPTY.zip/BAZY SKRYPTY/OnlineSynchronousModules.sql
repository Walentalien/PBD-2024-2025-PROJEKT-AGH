--Select * from CourseModules

INSERT INTO OnlineSynchronousModules (ModuleID, MeetingLink, RecordingLink)
VALUES 
(9, '<meetinglink>', 'recordinglink'),
(10, '<meetinglink>', 'recordinglink'),
(11, '<meetinglink>', 'recordinglink'),
(12, '<meetinglink>', 'recordinglink'),
(13, '<meetinglink>', 'recordinglink'),
(14, '<meetinglink>', 'recordinglink'),
(15, '<meetinglink>', 'recordinglink'),

(25, '<meetinglink>', 'recordinglink'),
(26, '<meetinglink>', 'recordinglink'),
(27, '<meetinglink>', 'recordinglink'),
(28, '<meetinglink>', 'recordinglink'),
(29, '<meetinglink>', 'recordinglink'),
(30, '<meetinglink>', 'recordinglink'),
(31, '<meetinglink>', 'recordinglink'),
(32, '<meetinglink>', 'recordinglink'),
(33, '<meetinglink>', 'recordinglink'),
(34, '<meetinglink>', 'recordinglink'),
(35, '<meetinglink>', 'recordinglink'),
(36, '<meetinglink>', 'recordinglink'),
(37, '<meetinglink>', 'recordinglink')
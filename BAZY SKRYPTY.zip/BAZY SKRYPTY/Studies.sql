--select * from Studies


INSERT INTO Studies (StudyID, StudyTitle, StudyDescription, StudySupervisorID, AdvancePaymentPrice)
VALUES
(1, 'Informatyka 2024/2025', 'Studia informatyczne', 5, 600.00),
(2, 'Matematyka 2024/2025', 'Studia matematyczne', 3, 600.00)

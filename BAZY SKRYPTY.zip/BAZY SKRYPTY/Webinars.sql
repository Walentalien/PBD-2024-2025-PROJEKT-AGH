--select * from Webinars

INSERT INTO Webinars (WebinarID, LecturerID, TranslatorID, WebinarTitle, WebinarDescription, WebinarDate, Duration, WebinarPrice, RecordingLink, LanguageID)
VALUES
(1, 3, NULL, 'O pi�knie matematyki 1', 'Powitanie na pierwszym webinarze, Podstawowe zagadnienia', '2024-05-01 12:00:00', '02:00:00', 30.00, '<link>', 1),
(2, 3, NULL, 'O pi�knie matematyki 2', 'Podstawowe zagadnienia', '2024-06-01 12:00:00', '02:00:00', 00.00, '<link>', 1),
(3, 3, NULL, 'O pi�knie matematyki 3', 'Zaawansowane zagadnienia', '2024-06-01 12:00:00', '02:00:00', 00.00, '<link>', 1),
(4, 3, NULL, 'O pi�knie matematyki 4', 'Zaawansowane zagadnienia', '2024-07-01 12:00:00', '02:00:00', 30.00, '<link>', 1),
(5, 3, NULL, 'O pi�knie matematyki 5', 'Zaawansowane zagadnienia', '2024-08-01 12:00:00', '02:00:00', 30.00, '<link>', 1),
(6, 3, NULL, 'O pi�knie matematyki 6', 'Zaawansowane zagadnienia', '2024-09-01 12:00:00', '02:00:00', 30.00, '<link>', 1),
(7, 3, NULL, 'O pi�knie matematyki 7', 'Zaawansowane zagadnienia', '2024-10-01 12:00:00', '02:00:00', 30.00, '<link>', 1),
(8, 3, NULL, 'O pi�knie matematyki 8', 'Zaawansowane zagadnienia', '2024-11-01 12:00:00', '02:00:00', 30.00, '<link>', 1),
(9, 3, NULL, 'O pi�knie matematyki 9', 'Zaawansowane zagadnienia', '2024-12-01 12:00:00', '02:00:00', 30.00, '<link>', 1),
(10, 3, NULL, 'O pi�knie matematyki 10', 'Zaawansowane zagadnienia', '2025-01-01 12:00:00', '02:00:00', 30.00, '<link>', 1),

(11, 4, NULL, 'Ciekawostki fizyczne 1', 'Powitanie na pierwszym webinarze, Podstawowe zagadnienia', '2024-05-01 12:00:00', '02:00:00', 00.00, '<link>', 1),
(12, 4, NULL, 'Ciekawostki fizyczne 2', 'Podstawowe zagadnienia', '2024-06-07 14:00:00', '01:30:00', 00.00, '<link>', 1),
(13, 4, NULL, 'Ciekawostki fizyczne 3', 'Zaawansowane zagadnienia', '2024-06-07 14:00:00', '01:30:00', 35.00, '<link>', 1),
(14, 4, NULL, 'Ciekawostki fizyczne 4', 'Zaawansowane zagadnienia', '2024-07-07 14:00:00', '01:30:00', 35.00, '<link>', 1),
(15, 4, NULL, 'Ciekawostki fizyczne 5', 'Zaawansowane zagadnienia', '2024-08-07 14:00:00', '01:30:00', 35.00, '<link>', 1),
(16, 4, NULL, 'Ciekawostki fizyczne 6', 'Zaawansowane zagadnienia', '2024-09-07 14:00:00', '01:30:00', 35.00, '<link>', 1),
(17, 4, NULL, 'Ciekawostki fizyczne 7', 'Zaawansowane zagadnienia', '2024-10-07 14:00:00', '01:30:00', 35.00, '<link>', 1),
(18, 4, NULL, 'Ciekawostki fizyczne 8', 'Zaawansowane zagadnienia', '2024-11-07 14:00:00', '01:30:00', 35.00, '<link>', 1),
(19, 4, NULL, 'Ciekawostki fizyczne 9', 'Zaawansowane zagadnienia', '2024-12-07 14:00:00', '01:30:00', 35.00, '<link>', 1),
(20, 4, NULL, 'Ciekawostki fizyczne 10', 'Zaawansowane zagadnienia', '2025-01-07 14:00:00', '01:30:00', 35.00, '<link>', 1),

(21, 9, 3, 'Historia Czech 1', 'Powitanie na pierwszym webinarze, Wst�p do historii Czech', '2024-07-23 17:00:00', '02:15:00', 00.00, '<link>', 7),
(22, 9, 3, 'Historia Czech 2', 'Pocz�tki pa�stwa', '2024-07-23 17:00:00', '02:15:00', 00.00, '<link>', 7),
(23, 9, 3, 'Historia Czech 3', 'Dalsze losy Czech', '2024-07-23 17:00:00', '02:15:00', 40.00, '<link>', 7),
(24, 9, 3, 'Historia Czech 4', 'Dalsze losy Czech', '2024-07-23 17:00:00', '02:15:00', 40.00, '<link>', 7),
(25, 9, 3, 'Historia Czech 5', 'Dalsze losy Czech', '2024-07-23 17:00:00', '02:15:00', 40.00, '<link>', 7),
(26, 9, 3, 'Historia Czech 6', 'Dalsze losy Czech', '2024-07-23 17:00:00', '02:15:00', 40.00, '<link>', 7),
(27, 9, 3, 'Historia Czech 7', 'Dalsze losy Czech', '2024-07-23 17:00:00', '02:15:00', 40.00, '<link>', 7),
(28, 9, 3, 'Historia Czech 8', 'Dalsze losy Czech', '2024-07-23 17:00:00', '02:15:00', 40.00, '<link>', 7),
(29, 9, 3, 'Historia Czech 9', 'Dalsze losy Czech', '2024-07-23 17:00:00', '02:15:00', 40.00, '<link>', 7),
(30, 9, 3, 'Historia Czech 10', 'Dalsze losy Czech', '2024-07-23 17:00:00', '02:15:00', 40.00, '<link>', 7),
(31, 9, 3, 'Historia Czech 11', 'Dalsze losy Czech', '2024-07-23 17:00:00', '02:15:00', 40.00, '<link>', 7)
--select * from OrderedStudyMeetings

INSERT OrderedStudyMeetings(ProductID, StudyMeetingID)
VALUES
(20,37),
(21,50)
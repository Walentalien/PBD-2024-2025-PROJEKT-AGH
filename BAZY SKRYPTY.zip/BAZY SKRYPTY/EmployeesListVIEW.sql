CREATE VIEW EmployeesList AS

(SELECT FirstName, LastName, EmployeeFunctionName AS EmployeeFunction, Email, PhoneNumber 
FROM Employees AS e
INNER JOIN EmployeeFunctions AS ef ON e.EmployeeFunctionID = ef.EmployeeFunctionID

UNION

SELECT FirstName, LastName, 'Translator' AS EmployeeFunction, Email, PhoneNumber
FROM Translators AS t) 










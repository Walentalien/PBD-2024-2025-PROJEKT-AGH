CREATE VIEW FutureWebinars AS

SELECT WebinarID, WebinarTitle, WebinarDate
FROM Webinars AS w
WHERE w.WebinarDate > GETDATE();


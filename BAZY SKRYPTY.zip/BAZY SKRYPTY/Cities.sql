-- usuni�to kolumn� PostalCode
--ALTER TABLE Cities
--DROP COLUMN PostalCode;

--SELECT * FROM Cities

-- wygenerowano r�cznie
INSERT INTO Cities (CityID, City, CountryID)
VALUES 
(1, 'Krak�w', 1),
(2, 'Warszawa', 1),
(3, 'Gda�sk', 1),
(4, 'Katowice', 1),
(5, '��d�', 1),
(6, 'Pozna�', 1),
(7, 'Szczecin', 1),
(8, 'Bia�ystok', 1),
(9, 'Lublin', 1),
(10, 'Bydgoszcz', 1),
(11, 'Cz�stochowa', 1),
(12, 'Radom', 1),
(13, 'Tychy', 1),
(14, 'Olsztyn', 1),
(15, 'P�ock', 1),
(16, 'Wroc�aw', 1),
(17, '�winouj�cie', 1),
(18, 'Zielona G�ra', 1),
(19, 'Gdynia', 1),
(20, 'Gliwice', 1),
(21, 'Zabrze', 1),
(22, 'Sosnowiec', 1),
(23, 'Wadowice', 1),
(24, 'Wieliczka', 1),
(25, 'Bochnia', 1),
(26, 'Brzesko', 1),
(27, 'Olkusz', 1),
(28, 'My�lenice', 1),
(29, 'Zakopane', 1),
(30, 'Rzesz�w', 1),
(31, 'Krosno', 1),
(32, 'Praga', 37),
(33, 'Kij�w', 178),
(34, 'Lw�w', 178),
(35, 'Zaporo�e', 178),
(36, 'Berlin', 124),
(37, 'Monachium', 124),
(38, 'Hamburg', 124),
(39, 'Pary�', 52),
(40, 'Lyon', 52),
(41, 'Londyn', 185),
(42, 'Edynburg', 185),
(43, 'Birmingham', 185),
(44, 'Nowy Jork', 159),
(45, 'Chicago', 159),
(46, 'Pekin', 32),
(47, 'Tokio', 76)




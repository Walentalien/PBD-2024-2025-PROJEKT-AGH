CREATE VIEW FutureEvents AS

SELECT 'StudyMeeting' AS Category, StudyMeetingID AS EventID, MeetingTitle AS EventTitle, MeetingDate AS EventDate FROM FutureStudies AS fs

UNION

SELECT 'Webinar' AS Category, WebinarID AS EventID, WebinarTitle AS EventTitle, WebinarDate AS EventDate FROM FutureWebinars AS fw

UNION

SELECT 'CourseModule' AS Category, ModuleID AS EventID, ModuleTitle AS EventTitle, ModuleDate AS EventDate FROM FutureCourses AS fc



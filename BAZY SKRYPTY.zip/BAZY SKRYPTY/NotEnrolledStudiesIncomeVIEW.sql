CREATE VIEW NotEnrolledStudiesIncome AS

SELECT s.StudyID, StudyTitle, SUM(PaidValue) AS Income
FROM OrderDetails AS od 
INNER JOIN OrderedStudyMeetings AS osm ON od.ProductID = osm.ProductID
INNER JOIN StudyMeetings AS sm ON sm.StudyMeetingID = osm.StudyMeetingID
INNER JOIN Subjects AS sbj ON sbj.SubjectID = sm.SubjectID
INNER JOIN Studies AS s ON s.StudyID = sbj.StudyID
GROUP BY s.StudyID, StudyTitle





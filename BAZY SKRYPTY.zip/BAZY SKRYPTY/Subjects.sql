--select * from Studies

INSERT INTO Subjects (StudyID, SubjectID, SubjectSupervisorID, SubjectTitle, SubjectDescription, SubjectSemester)
VALUES
(1, 1, 3, 'Matematyka 1 (Informatyka 2024/2025)', 'Matematyka dla informatyk�w cz�� 1.', 1),
(1, 2, 5, 'Podstawy Programowania (Informatyka 2024/2025))', 'Podstawy programowania w j�zyku Python', 1),
(1, 3, 7, 'System UNIX (Informatyka 2024/2025)', 'Podstawy dzia�ania w systemie UNIX', 1),

(1, 4, 3, 'Matematyka 2 (Informatyka 2024/2025)', 'Matematyka dla informatyk�w cz�� 2.', 2),
(1, 5, 5, 'Algorytmika 1 (Informatyka 2024/2025)', 'Podstawy algorytmiki', 2),
(1, 6, 5, 'Programowanie w j�zyku C++ (Informatyka 2024/2025)', 'Programowanie w j�zyku C++', 2),

(1, 7, 8, 'Programowanie w j�zyku Java (Informatyka 2024/2025)', 'Programowanie obiektowe w j�zyku Java', 3),
(1, 8, 5, 'Algorytmika 2 (Informatyka 2024/2025)', 'Zaawansowane zagadnienia algorytmiczne', 3),
(1, 9, 3, 'Matematyka 3 (Informatyka 2024/2025)', 'Matematyka dla informatyk�w cz�� 3.', 3),

(1, 10, 8, 'Bazy Danych 1 (Informatyka 2024/2025)', 'Zapytania w j�zyku SQL', 4),
(1, 11, 6, 'Aplikacje Internetowe 1 (Informatyka 2024/2025)', 'Podstawy tworzenia stron internetowych', 4),
(1, 12, 6, 'Aplikacje mobilne (Informatyka 2024/2025)', 'Podstawy aplikacji mobilnych', 4),

(1, 13, 8, 'Bazy Danych 2 (Informatyka 2024/2025)', 'Implementacja w�asnej bazy danych', 5),
(1, 14, 6, 'Aplikacje Internetowe 2 (Informatyka 2024/2025)', 'Zaawansowane metody tworzenia stron internetowych', 5),
(1, 15, 4, 'Assembler (Informatyka 2024/2025)', 'Programowanie w j�zyku Assembler', 5),

(1, 16, 7, 'Systemy Operacyjne (Informatyka 2024/2025)', 'Implementacja w�asnej bazy danych', 6),
(1, 17, 5, 'Licencjat (Informatyka 2024/2025)', 'Pisanie pracy licencjackiej', 6),


(2, 18, 3, 'Algebra 1 (Matematyka 2024/2025)', 'Algebra liniowa z geometri� cz�� 1.', 1),
(2, 19, 3, 'Analiza Matematyczna 1 (Matematyka 2024/2025)', 'Analiza matematyczna cz�� 1.', 1),
(2, 20, 4, 'Logika Matematyczna (Matematyka 2024/2025)', 'Podstawy logiki matematycznej', 1),

(2, 21, 3, 'Algebra 2 (Matematyka 2024/2025)', 'Algebra liniowa z geometri� cz�� 2.', 2),
(2, 22, 3, 'Analiza Matematyczna 2 (Matematyka 2024/2025)', 'Analiza matematyczna cz�� 2.', 2),
(2, 23, 5, 'Podstawy Programowania 1 (Matematyka 2024/2025)', 'Podstawy programowania dla matematyk�w cz�� 1.', 2),

(2, 24, 5, 'Podstawy Programowania 2 (Matematyka 2024/2025)', 'Podstawy programowania dla matematyk�w cz�� 2.', 3),
(2, 25, 3, 'R�wnania R�niczkowe (Matematyka 2024/2025)', 'Podstawy rozwi�zywania r�wna� r�niczkowych', 3),
(2, 26, 4, 'Matematyka Dyskretna 1 (Matematyka 2024/2025)', 'Kombinatoryka', 3),

(2, 27, 4, 'Matematyka Dyskretna 2 (Matematyka 2024/2025)', 'Teoria graf�w', 4),
(2, 28, 3, 'Algebra 3 (Matematyka 2024/2025)', 'Algebra cz�� 3.', 4),
(2, 29, 3, 'Analiza Matematyczna 3 (Matematyka 2024/2025)', 'Analiza matematyczna cz�� 3.', 4),

(2, 30, 4, 'Rachunek prawdopodobie�stwa (Matematyka 2024/2025)', 'Wst�p do rachunku prawdopodobie�twa', 5),
(2, 31, 3, 'Analiza Zespolona (Matematyka 2024/2025)', 'Analiza matematyczna cz�� 4.', 5),
(2, 32, 8, 'Matlab (Matematyka 2024/2025)', 'Podstawy Matlab', 5),

(2, 33, 4, 'Statystyka (Matematyka 2024/2025)', 'Statystyka', 6),
(2, 34, 3, 'Licencjat (Matematyka 2024/2025)', 'Pisanie pracy licencjackiej', 6)


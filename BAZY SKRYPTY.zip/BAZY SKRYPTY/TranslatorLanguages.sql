INSERT INTO TranslatorLanguages (TranslatorID, LanguageID)
VALUES 
(1,1),
(1,2),
(1,3),
(1,4),

(2,1),
(2,4),
(2,5),

(3,1),
(3,7),
(3,8),
(3,9),

(4,1),
(4,6),
(4,10)


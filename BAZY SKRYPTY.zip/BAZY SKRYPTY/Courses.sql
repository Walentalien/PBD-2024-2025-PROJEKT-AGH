--SELECT * from courses

INSERT INTO Courses (CourseID, CourseTitle, CourseDescription, AdvancePaymentPrice, CoursePrice, CourseSupervisorID)
VALUES
(1, 'Programowanie w Python', 'Kurs dotycz�cy podstaw programowania w j�zyku Python', 300.00, 1000.00, 5),
(2, 'Tworzenie stron internetowych', 'Kurs tworzenia stron internetowych obejmuj�cy zagadnienia takie jak: HTML, CSS, JavaScript, React', 500.00, 1500.00, 6),
(3, 'Programowanie w C++', 'Kurs dotycz�cy podstaw programowania w j�zyku C++', 300.00, 1000.00, 5),
(4, 'Matematyka dla maturzyst�w', 'Kurs przygotowuj�cy do matury z matematyki rozszerzonej', 100.00, 350.00, 3),
(5, 'Programowanie w Java', 'Kurs dotycz�cy podstaw programowania w j�zyku Java', 300.00, 1000.00, 7)
--SELECT * FROM StudiesGrades

INSERT INTO StudiesGrades (StudyID, StudentID, StudyGrade)
VALUES
(1,20,72),
(2,21,64)
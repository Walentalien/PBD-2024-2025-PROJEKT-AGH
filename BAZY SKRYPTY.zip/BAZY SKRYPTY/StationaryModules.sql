--Select * from CourseModules

INSERT INTO StationaryModules (ModuleID, RoomID)
VALUES
(16, 7),

(1, 8),
(2, 8),
(3, 8),
(4, 8),
(5, 8),
(6, 8),
(7, 8),
(8, 8),

(17, 1),
(18, 1),
(19, 1),
(20, 1),
(21, 1),
(22, 1),
(23, 1),
(24, 1)
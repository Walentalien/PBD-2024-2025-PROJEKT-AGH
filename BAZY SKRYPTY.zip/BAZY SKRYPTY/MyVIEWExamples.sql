SELECT * FROM AllIncomes ;
SELECT * FROM CoursesIncome;
SELECT * FROM DebtorsList;
SELECT * FROM EmployeesList;
SELECT * FROM EnrolledStudiesIncome;
SELECT * FROM NotEnrolledStudiesIncome;
SELECT * FROM NotEnrolledStudiesMeetingsIncome;
SELECT * FROM StudiesIncome;
SELECT * FROM WebinarsIncome;

SELECT * FROM FutureWebinars;
SELECT * FROM FutureCourses;
SELECT * FROM FutureStudies;


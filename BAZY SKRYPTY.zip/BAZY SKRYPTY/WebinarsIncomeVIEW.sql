CREATE VIEW WebinarsIncome AS

SELECT w.WebinarID, WebinarTitle, SUM(PaidValue) AS Income
FROM OrderDetails AS od 
INNER JOIN OrderedWebinars AS ow ON od.ProductID = ow.ProductID 
INNER JOIN Webinars AS w ON ow.WebinarID = w.WebinarID
GROUP BY w.WebinarID, WebinarTitle





CREATE VIEW AllIncomes AS

SELECT u.Category, u.ID, u.Title, u.Income AS Income FROM
(SELECT 'Study' AS Category, si.StudyID AS ID, si.StudyTitle AS Title, si.Income AS Income 
FROM StudiesIncome AS si

UNION

SELECT 'Webinar' AS Category, wi.WebinarID AS ID, wi.WebinarTitle AS Title, wi.Income AS Income 
FROM WebinarsIncome AS wi

UNION 

SELECT 'Course' AS Category, ci.CourseID AS ID, ci.CourseTitle AS Title, ci.Income AS Income 
FROM CoursesIncome AS ci) AS u





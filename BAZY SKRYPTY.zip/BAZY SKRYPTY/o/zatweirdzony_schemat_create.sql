-- Created by Vertabelo (http://vertabelo.com)
-- Last modification date: 2025-01-06 16:52:39.869

-- tables
-- Table: Cities
CREATE TABLE Cities (
    CityID int  NOT NULL,
    City nvarchar(100)  NOT NULL,
    CountryID int  NOT NULL,
    PostalCode nvarchar(20)  NOT NULL,
    CONSTRAINT Cities_pk PRIMARY KEY  (CityID)
);

-- Table: Countries
CREATE TABLE Countries (
    CountryID int  NOT NULL,
    CountryName nvarchar(50) NOT NULL,
    CONSTRAINT Countries_pk PRIMARY KEY  (CountryID)
);

-- Table: CourseModulePresence
CREATE TABLE CourseModulePresence (
    ModuleID int  NOT NULL,
    StudentID int  NOT NULL,
    Presence int  NULL,
    CONSTRAINT CHECK_11 CHECK (( Presence IN ( 0 , 1 ) )),
    CONSTRAINT CourseModulePresence_pk PRIMARY KEY  (ModuleID,StudentID)
);

-- Table: CourseModules
CREATE TABLE CourseModules (
    ModuleID int  NOT NULL,
    CourseID int  NOT NULL,
    LecturerID int  NOT NULL,
    ModuleTitle nvarchar(255)  NOT NULL,
    ModuleDate datetime  NOT NULL,
    Duration time  NOT NULL,
    LanguageID int  NOT NULL,
    TranslatorID int  NULL,
    CONSTRAINT CourseModules_pk PRIMARY KEY  (ModuleID)
);

-- Table: CourseParticipants
CREATE TABLE CourseParticipants (
    CourseID int  NOT NULL,
    StudentID int  NOT NULL,
    CONSTRAINT CourseParticipants_pk PRIMARY KEY  (StudentID,CourseID)
);

-- Table: Courses
CREATE TABLE Courses (
    CourseID int  NOT NULL,
    CourseTitle nvarchar(255)  NOT NULL,
    CourseDescription nvarchar(max)  NULL,
    AdvancePaymentPrice money  NOT NULL,
    CoursePrice money  NOT NULL,
    CourseSupervisorID int  ,--NOT NULL,
    CONSTRAINT CHECK_9 CHECK (( AdvancePaymentPrice >= 0 )),
    CONSTRAINT CHECK_10 CHECK (( CoursePrice >= 0 )),
    CONSTRAINT Courses_pk PRIMARY KEY  (CourseID)
);

-- Table: EmployeeFunctions
CREATE TABLE EmployeeFunctions (
    EmployeeFunctionID int  NOT NULL,
    EmployeeFunctionName nvarchar(100)  NOT NULL,
    CONSTRAINT EmployeeFunctions_pk PRIMARY KEY  (EmployeeFunctionID)
);

-- Table: Employees
CREATE TABLE Employees (
    EmployeeID int  NOT NULL,
    FirstName nvarchar(50)  NOT NULL,
    SecondName nvarchar(50)  NULL,
    LastName nvarchar(50)  NOT NULL,
    Address nvarchar(255)  NOT NULL,
    CityID int  NOT NULL,
    BirthDate date  NOT NULL,
    HireDate date  NOT NULL,
    Email nvarchar(100)  NOT NULL,
    PhoneNumber nvarchar(20)  NOT NULL,
    EmployeeFunctionID int  NOT NULL,
    CONSTRAINT AK_2 UNIQUE (PhoneNumber),
    CONSTRAINT CHECK_2 CHECK (( Email LIKE '%_@_%._%' )),
    CONSTRAINT CHECK_3 CHECK (( len ( PhoneNumber ) = 9 and ISNUMERIC ( PhoneNumber ) = 1)),
    CONSTRAINT Employees_pk PRIMARY KEY  (EmployeeID)
);

-- Table: Internship
CREATE TABLE Internship (
    InternshipID int  NOT NULL,
    StudyID int  NOT NULL,
    StartDate date  NOT NULL,
    --CONSTRAINT CHECK_15 CHECK (( StartDate >= GETDATE ( ) )), DROPPED
    CONSTRAINT Internship_pk PRIMARY KEY  (InternshipID)
);

-- Table: InternshipPresence
CREATE TABLE InternshipPresence (
    InternshipID int  NOT NULL,
    StudentID int  NOT NULL,
    Presence int  NULL,
    CONSTRAINT CHECK_16 CHECK (( Presence IN ( 0 , 1 ) )),
    CONSTRAINT InternshipPresence_pk PRIMARY KEY  (InternshipID,StudentID)
);

-- Table: Languages
CREATE TABLE Languages (
    LanguageID int  NOT NULL,
    LanguageName nvarchar(50)  NOT NULL,
    CONSTRAINT Languages_pk PRIMARY KEY  (LanguageID)
);

-- Table: OnlineAsynchronousMeetings
CREATE TABLE OnlineAsynchronousMeetings (
    StudyMeetingID int  NOT NULL,
    VideoLink nvarchar(max)  NOT NULL,
    CONSTRAINT OnlineAsynchronousMeetings_pk PRIMARY KEY  (StudyMeetingID)
);

-- Table: OnlineAsynchronousModules
CREATE TABLE OnlineAsynchronousModules (
    ModuleID int  NOT NULL,
    VideoLink nvarchar(max)  NOT NULL,
    CONSTRAINT OnlineAsynchronousModules_pk PRIMARY KEY  (ModuleID)
);

-- Table: OnlineSynchronousMeetings
CREATE TABLE OnlineSynchronousMeetings (
    StudyMeetingID int  NOT NULL,
    MeetingLink nvarchar(max)  NULL,
    RecordingLink nvarchar(max)  NULL,
    CONSTRAINT OnlineSynchronousMeetings_pk PRIMARY KEY  (StudyMeetingID)
);

-- Table: OnlineSynchronousModules
CREATE TABLE OnlineSynchronousModules (
    ModuleID int  NOT NULL,
    MeetingLink nvarchar(max)  NOT NULL,
    RecordingLink nvarchar(max)  NULL,
    CONSTRAINT OnlineSynchronousModules_pk PRIMARY KEY  (ModuleID)
);

-- Table: OrderDetails
CREATE TABLE OrderDetails (
    ProductID int  NOT NULL,
    OrderID int  NULL,
    PaidValue money  NULL,
    PaymentPaid bit  NULL,
    PaidDate date  NULL,
    AdvancePaymentPaid bit  NULL,
    AdvancePaymentDate date  NULL,
    CONSTRAINT CHECK_20 CHECK (( PaidValue >= 0 )),
    CONSTRAINT OrderDetails_pk PRIMARY KEY  (ProductID)
);

-- Table: OrderedCourses
CREATE TABLE OrderedCourses (
    ProductID int  NOT NULL,
    CourseID int  NULL,
    CONSTRAINT OrderedCourses_pk PRIMARY KEY  (ProductID)
);

-- Table: OrderedStudies
CREATE TABLE OrderedStudies (
    ProductID int  NOT NULL,
    StudyID int  NULL,
    CONSTRAINT OrderedStudies_pk PRIMARY KEY  (ProductID)
);

-- Table: OrderedStudyMeetings
CREATE TABLE OrderedStudyMeetings (
    ProductID int  NOT NULL,
    StudyMeetingID int  NULL,
    CONSTRAINT OrderedStudyMeetings_pk PRIMARY KEY  (ProductID)
);

-- Table: OrderedWebinars
CREATE TABLE OrderedWebinars (
    ProductID int  NOT NULL,
    WebinarID int  NULL,
    CONSTRAINT OrderedWebinars_pk PRIMARY KEY  (ProductID)
);

-- Table: Orders
CREATE TABLE Orders (
    OrderID int  NOT NULL,
    StudentID int  NULL,
    OrderDate date  NULL,
    CONSTRAINT Orders_pk PRIMARY KEY  (OrderID)
);

-- Table: Rooms
CREATE TABLE Rooms (
    RoomID int  NOT NULL,
    RoomCapacity int  NOT NULL,
    CONSTRAINT CHECK_7 CHECK (( RoomCapacity > 0 )),
    CONSTRAINT Rooms_pk PRIMARY KEY  (RoomID)
);

-- Table: StationaryMeetings
CREATE TABLE StationaryMeetings (
    StudyMeetingID int  NOT NULL,
    RoomID int  NULL,
    CONSTRAINT StationaryMeetings_pk PRIMARY KEY  (StudyMeetingID)
);

-- Table: StationaryModules
CREATE TABLE StationaryModules (
    ModuleID int  NOT NULL,
    RoomID int  NULL,
    CONSTRAINT StationaryModules_pk PRIMARY KEY  (ModuleID)
);

-- Table: Students
CREATE TABLE Students (
    StudentID int  NOT NULL,
    FirstName nvarchar(50)  NOT NULL,
    LastName nvarchar(50)  NOT NULL,
    Address nvarchar(255)  NOT NULL,
    CityID int  NOT NULL,
    BirthDate date  NOT NULL,
    Email nvarchar(100)  NOT NULL,
    PhoneNumber nvarchar(20)  NOT NULL,
    CONSTRAINT AK_0 UNIQUE (Email),
    CONSTRAINT AK_1 UNIQUE (PhoneNumber),
    CONSTRAINT CHECK_0 CHECK (( Email like '%_@_%._%' )),
    CONSTRAINT CHECK_1 CHECK (( len ( PhoneNumber ) = 9 and ISNUMERIC ( PhoneNumber ) = 1 )),
    CONSTRAINT Students_pk PRIMARY KEY  (StudentID)
);

-- Table: Studies
CREATE TABLE Studies (
    StudyID int  NOT NULL,
    StudyTitle nvarchar(255)  NOT NULL,
    StudyDescription nvarchar(max)  NULL,
    StudySupervisorID int  NOT NULL,
    AdvancePaymentPrice money  NOT NULL,
    CONSTRAINT CHECK_12 CHECK (( AdvancePaymentPrice >= 0 )),
    CONSTRAINT Studies_pk PRIMARY KEY  (StudyID)
);

-- Table: StudiesGrades
CREATE TABLE StudiesGrades (
    StudyID int  NOT NULL,
    StudentID int  NOT NULL,
    StudyGrade int  NULL,
    CONSTRAINT CHECK_14 CHECK (( StudyGrade >= 0 AND StudyGrade <= 100 )),
    CONSTRAINT StudiesGrades_pk PRIMARY KEY  (StudyID,StudentID)
);

-- Table: StudyMeetingPresence
CREATE TABLE StudyMeetingPresence (
    StudyMeetingID int  NOT NULL,
    StudentID int  NOT NULL,
    Presence int  NULL,
    CONSTRAINT CHECK_19 CHECK (( Presence IN ( 0 , 1 ) )),
    CONSTRAINT StudyMeetingPresence_pk PRIMARY KEY  (StudyMeetingID,StudentID)
);

-- Table: StudyMeetings
CREATE TABLE StudyMeetings (
    StudyMeetingID int  NOT NULL,
    SubjectID int  NOT NULL,
    LecturerID int  NOT NULL,
    MeetingTitle nvarchar(255)  NOT NULL,
    MeetingPrice money  NOT NULL,
    GuestMeetingPrice money  NOT NULL,
    MeetingDate datetime  NOT NULL,
    Duration time  NOT NULL,
    LanguageID int  NOT NULL,
    TranslatorID int  NULL,
    CONSTRAINT CHECK_17 CHECK (( MeetingPrice >= 0 )),
    CONSTRAINT CHECK_18 CHECK (( GuestMeetingPrice >= 0 )),
    CONSTRAINT StudyMeetings_pk PRIMARY KEY  (StudyMeetingID)
);

-- Table: SubjectGrades
CREATE TABLE SubjectGrades (
    SubjectID int  NOT NULL,
    StudentID int  NOT NULL,
    SubjectGrade int  NULL,
    CONSTRAINT CHECK_13 CHECK (( SubjectGrade >= 0 AND SubjectGrade <= 100 )),
    CONSTRAINT SubjectGrades_pk PRIMARY KEY  (SubjectID,StudentID)
);

-- Table: SubjectParticipants
CREATE TABLE SubjectParticipants (
    SubjectID int  NOT NULL,
    StudentID int  NOT NULL,
    SubjectGrade float  NULL,
    CONSTRAINT SubjectParticipants_pk PRIMARY KEY  (SubjectID,StudentID)
);

-- Table: Subjects
CREATE TABLE Subjects (
    StudyID int  NOT NULL,
    SubjectID int  NOT NULL,
    SubjectSupervisorID int  NOT NULL,
    SubjectTitle nvarchar(255)  NOT NULL,
    SubjectDescription nvarchar(max)  NULL,
    SubjectSemester int  NOT NULL,
    CONSTRAINT Subjects_pk PRIMARY KEY  (SubjectID)
);

-- Table: TranslatorLanguages
CREATE TABLE TranslatorLanguages (
    TranslatorID int  NOT NULL,
    LanguageID int  NOT NULL,
    CONSTRAINT TranslatorLanguages_pk PRIMARY KEY  (TranslatorID,LanguageID)
);

-- Table: Translators
CREATE TABLE Translators (
    TranslatorID int  NOT NULL,
    FirstName nvarchar(50)  NOT NULL,
    LastName nvarchar(50)  NOT NULL,
    Address nvarchar(255)  NOT NULL,
    CityID int  NOT NULL,
    BirthDate date  NOT NULL,
    HireDate date  NOT NULL,
    Email nvarchar(100)  NOT NULL,
    PhoneNumber nvarchar(20)  NOT NULL,
    CONSTRAINT AK_3 UNIQUE (Email),
    CONSTRAINT AK_4 UNIQUE (PhoneNumber),
    CONSTRAINT CHECK_4 CHECK (( HireDate > BirthDate )),
    CONSTRAINT CHECK_5 CHECK (( Email LIKE '%_@_%._%' )),
    CONSTRAINT CHECK_6 CHECK (( LEN ( PhoneNumber ) = 9 AND ISNUMERIC ( PhoneNumber ) = 1)),
    CONSTRAINT Translators_pk PRIMARY KEY  (TranslatorID)
);

-- Table: WebinarAccess
CREATE TABLE WebinarAccess (
    StudentID int  NOT NULL,
    WebinarID int  NOT NULL,
    AvailableUntil date  NOT NULL,
    CONSTRAINT WebinarAccess_pk PRIMARY KEY  (StudentID,WebinarID)
);

-- Table: Webinars
CREATE TABLE Webinars (
    WebinarID int  NOT NULL,
    LecturerID int  NOT NULL,
    TranslatorID int  NULL,
    WebinarTitle nvarchar(255)  NOT NULL,
    WebinarDescription nvarchar(max)  NULL,
    WebinarDate datetime  NOT NULL,
    Duration time  NOT NULL,
    WebinarPrice money  NOT NULL,
    RecordingLink nvarchar(300)  NULL,
    LanguageID int  NOT NULL,
    CONSTRAINT CHECK_8 CHECK (( WebinarPrice >= 0 )),
    CONSTRAINT Webinars_pk PRIMARY KEY  (WebinarID)
);

-- foreign keys
-- Reference: FK_0 (table: Cities)
ALTER TABLE Cities ADD CONSTRAINT FK_0
    FOREIGN KEY (CountryID)
    REFERENCES Countries (CountryID);

-- Reference: FK_1 (table: Students)
ALTER TABLE Students ADD CONSTRAINT FK_1
    FOREIGN KEY (CityID)
    REFERENCES Cities (CityID);

-- Reference: FK_10 (table: WebinarAccess)
ALTER TABLE WebinarAccess ADD CONSTRAINT FK_10
    FOREIGN KEY (StudentID)
    REFERENCES Students (StudentID)
    ON DELETE  CASCADE;

-- Reference: FK_11 (table: WebinarAccess)
ALTER TABLE WebinarAccess ADD CONSTRAINT FK_11
    FOREIGN KEY (WebinarID)
    REFERENCES Webinars (WebinarID)
    ON DELETE  CASCADE;

-- Reference: FK_12 (table: Courses)
ALTER TABLE Courses ADD CONSTRAINT FK_12
    FOREIGN KEY (CourseSupervisorID)
    REFERENCES Employees (EmployeeID)
    ON DELETE  SET NULL;

-- Reference: FK_13 (table: CourseParticipants)
ALTER TABLE CourseParticipants ADD CONSTRAINT FK_13
    FOREIGN KEY (StudentID)
    REFERENCES Students (StudentID)
    ON DELETE  CASCADE;

-- Reference: FK_14 (table: CourseParticipants)
ALTER TABLE CourseParticipants ADD CONSTRAINT FK_14
    FOREIGN KEY (CourseID)
    REFERENCES Courses (CourseID)
    ON DELETE  CASCADE;

-- Reference: FK_15 (table: CourseModules)
ALTER TABLE CourseModules ADD CONSTRAINT FK_15
    FOREIGN KEY (CourseID)
    REFERENCES Courses (CourseID)
    ON DELETE  CASCADE;

-- Reference: FK_16 (table: CourseModules)
ALTER TABLE CourseModules ADD CONSTRAINT FK_16
    FOREIGN KEY (LecturerID)
    REFERENCES Employees (EmployeeID)
    ON DELETE  SET NULL;

-- Reference: FK_17 (table: CourseModules)
ALTER TABLE CourseModules ADD CONSTRAINT FK_17
    FOREIGN KEY (LanguageID)
    REFERENCES Languages (LanguageID)
    ON DELETE  CASCADE;

-- Reference: FK_18 (table: CourseModules)
ALTER TABLE CourseModules ADD CONSTRAINT FK_18
    FOREIGN KEY (TranslatorID)
    REFERENCES Translators (TranslatorID)
    ON DELETE  SET NULL;

-- Reference: FK_19 (table: OnlineAsynchronousModules)
ALTER TABLE OnlineAsynchronousModules ADD CONSTRAINT FK_19
    FOREIGN KEY (ModuleID)
    REFERENCES CourseModules (ModuleID)
    ON DELETE  CASCADE;

-- Reference: FK_2 (table: Employees)
ALTER TABLE Employees ADD CONSTRAINT FK_2
    FOREIGN KEY (CityID)
    REFERENCES Cities (CityID);

-- Reference: FK_20 (table: OnlineSynchronousModules)
ALTER TABLE OnlineSynchronousModules ADD CONSTRAINT FK_20
    FOREIGN KEY (ModuleID)
    REFERENCES CourseModules (ModuleID)
    ON DELETE  CASCADE;

-- Reference: FK_21 (table: StationaryModules)
ALTER TABLE StationaryModules ADD CONSTRAINT FK_21
    FOREIGN KEY (RoomID)
    REFERENCES Rooms (RoomID);

-- Reference: FK_22 (table: StationaryModules)
ALTER TABLE StationaryModules ADD CONSTRAINT FK_22
    FOREIGN KEY (ModuleID)
    REFERENCES CourseModules (ModuleID)
    ON DELETE  CASCADE;

-- Reference: FK_23 (table: CourseModulePresence)
ALTER TABLE CourseModulePresence ADD CONSTRAINT FK_23
    FOREIGN KEY (ModuleID)
    REFERENCES CourseModules (ModuleID)
    ON DELETE  CASCADE;

-- Reference: FK_24 (table: CourseModulePresence)
ALTER TABLE CourseModulePresence ADD CONSTRAINT FK_24
    FOREIGN KEY (StudentID)
    REFERENCES Students (StudentID)
    ON DELETE  CASCADE;

-- Reference: FK_25 (table: Studies)
ALTER TABLE Studies ADD CONSTRAINT FK_25
    FOREIGN KEY (StudySupervisorID)
    REFERENCES Employees (EmployeeID)
    ON DELETE  SET NULL;

-- Reference: FK_26 (table: Subjects)
ALTER TABLE Subjects ADD CONSTRAINT FK_26
    FOREIGN KEY (StudyID)
    REFERENCES Studies (StudyID)
    ON DELETE  CASCADE;

-- Reference: FK_27 (table: Subjects)
ALTER TABLE Subjects ADD CONSTRAINT FK_27
    FOREIGN KEY (SubjectSupervisorID)
    REFERENCES Employees (EmployeeID)
    ON DELETE  SET NULL;

-- Reference: FK_28 (table: SubjectParticipants)
ALTER TABLE SubjectParticipants ADD CONSTRAINT FK_28
    FOREIGN KEY (SubjectID)
    REFERENCES Subjects (SubjectID)
    ON DELETE  CASCADE;

-- Reference: FK_29 (table: SubjectParticipants)
ALTER TABLE SubjectParticipants ADD CONSTRAINT FK_29
    FOREIGN KEY (StudentID)
    REFERENCES Students (StudentID)
    ON DELETE  CASCADE;

-- Reference: FK_3 (table: Employees)
ALTER TABLE Employees ADD CONSTRAINT FK_3
    FOREIGN KEY (EmployeeFunctionID)
    REFERENCES EmployeeFunctions (EmployeeFunctionID);

-- Reference: FK_30 (table: SubjectGrades)
ALTER TABLE SubjectGrades ADD CONSTRAINT FK_30
    FOREIGN KEY (SubjectID)
    REFERENCES Subjects (SubjectID)
    ON DELETE  CASCADE;

-- Reference: FK_31 (table: SubjectGrades)
ALTER TABLE SubjectGrades ADD CONSTRAINT FK_31
    FOREIGN KEY (StudentID)
    REFERENCES Students (StudentID)
    ON DELETE  CASCADE;

-- Reference: FK_32 (table: StudiesGrades)
ALTER TABLE StudiesGrades ADD CONSTRAINT FK_32
    FOREIGN KEY (StudyID)
    REFERENCES Studies (StudyID)
    ON DELETE  CASCADE;

-- Reference: FK_33 (table: StudiesGrades)
ALTER TABLE StudiesGrades ADD CONSTRAINT FK_33
    FOREIGN KEY (StudentID)
    REFERENCES Students (StudentID)
    ON DELETE  CASCADE;

-- Reference: FK_34 (table: Internship)
ALTER TABLE Internship ADD CONSTRAINT FK_34
    FOREIGN KEY (StudyID)
    REFERENCES Studies (StudyID)
    ON DELETE  CASCADE;

-- Reference: FK_35 (table: InternshipPresence)
ALTER TABLE InternshipPresence ADD CONSTRAINT FK_35
    FOREIGN KEY (InternshipID)
    REFERENCES Internship (InternshipID)
    ON DELETE  CASCADE;

-- Reference: FK_36 (table: InternshipPresence)
ALTER TABLE InternshipPresence ADD CONSTRAINT FK_36
    FOREIGN KEY (StudentID)
    REFERENCES Students (StudentID)
    ON DELETE  CASCADE;

-- Reference: FK_37 (table: StudyMeetings)
ALTER TABLE StudyMeetings ADD CONSTRAINT FK_37
    FOREIGN KEY (SubjectID)
    REFERENCES Subjects (SubjectID)
    ON DELETE  CASCADE;

-- Reference: FK_38 (table: StudyMeetings)
ALTER TABLE StudyMeetings ADD CONSTRAINT FK_38
    FOREIGN KEY (LecturerID)
    REFERENCES Employees (EmployeeID)
    ON DELETE  SET NULL;

-- Reference: FK_39 (table: StudyMeetings)
ALTER TABLE StudyMeetings ADD CONSTRAINT FK_39
    FOREIGN KEY (LanguageID)
    REFERENCES Languages (LanguageID)
    ON DELETE  CASCADE;

-- Reference: FK_4 (table: Translators)
ALTER TABLE Translators ADD CONSTRAINT FK_4
    FOREIGN KEY (CityID)
    REFERENCES Cities (CityID);

-- Reference: FK_40 (table: StudyMeetings)
ALTER TABLE StudyMeetings ADD CONSTRAINT FK_40
    FOREIGN KEY (TranslatorID)
    REFERENCES Translators (TranslatorID)
    ON DELETE  SET NULL;

-- Reference: FK_41 (table: StudyMeetingPresence)
ALTER TABLE StudyMeetingPresence ADD CONSTRAINT FK_41
    FOREIGN KEY (StudyMeetingID)
    REFERENCES StudyMeetings (StudyMeetingID)
    ON DELETE  CASCADE;

-- Reference: FK_42 (table: StudyMeetingPresence)
ALTER TABLE StudyMeetingPresence ADD CONSTRAINT FK_42
    FOREIGN KEY (StudentID)
    REFERENCES Students (StudentID)
    ON DELETE  CASCADE;

-- Reference: FK_43 (table: OnlineAsynchronousMeetings)
ALTER TABLE OnlineAsynchronousMeetings ADD CONSTRAINT FK_43
    FOREIGN KEY (StudyMeetingID)
    REFERENCES StudyMeetings (StudyMeetingID)
    ON DELETE  CASCADE;

-- Reference: FK_44 (table: OnlineSynchronousMeetings)
ALTER TABLE OnlineSynchronousMeetings ADD CONSTRAINT FK_44
    FOREIGN KEY (StudyMeetingID)
    REFERENCES StudyMeetings (StudyMeetingID);

-- Reference: FK_45 (table: StationaryMeetings)
ALTER TABLE StationaryMeetings ADD CONSTRAINT FK_45
    FOREIGN KEY (StudyMeetingID)
    REFERENCES StudyMeetings (StudyMeetingID);

-- Reference: FK_46 (table: StationaryMeetings)
ALTER TABLE StationaryMeetings ADD CONSTRAINT FK_46
    FOREIGN KEY (RoomID)
    REFERENCES Rooms (RoomID);

-- Reference: FK_47 (table: Orders)
ALTER TABLE Orders ADD CONSTRAINT FK_47
    FOREIGN KEY (StudentID)
    REFERENCES Students (StudentID);

-- Reference: FK_48 (table: OrderDetails)
ALTER TABLE OrderDetails ADD CONSTRAINT FK_48
    FOREIGN KEY (OrderID)
    REFERENCES Orders (OrderID);

-- Reference: FK_49 (table: OrderedWebinars)
ALTER TABLE OrderedWebinars ADD CONSTRAINT FK_49
    FOREIGN KEY (ProductID)
    REFERENCES OrderDetails (ProductID);

-- Reference: FK_5 (table: TranslatorLanguages)
ALTER TABLE TranslatorLanguages ADD CONSTRAINT FK_5
    FOREIGN KEY (TranslatorID)
    REFERENCES Translators (TranslatorID);

-- Reference: FK_50 (table: OrderedWebinars)
ALTER TABLE OrderedWebinars ADD CONSTRAINT FK_50
    FOREIGN KEY (WebinarID)
    REFERENCES Webinars (WebinarID);

-- Reference: FK_51 (table: OrderedCourses)
ALTER TABLE OrderedCourses ADD CONSTRAINT FK_51
    FOREIGN KEY (ProductID)
    REFERENCES OrderDetails (ProductID);

-- Reference: FK_52 (table: OrderedCourses)
ALTER TABLE OrderedCourses ADD CONSTRAINT FK_52
    FOREIGN KEY (CourseID)
    REFERENCES Courses (CourseID);

-- Reference: FK_53 (table: OrderedStudies)
ALTER TABLE OrderedStudies ADD CONSTRAINT FK_53
    FOREIGN KEY (ProductID)
    REFERENCES OrderDetails (ProductID);

-- Reference: FK_54 (table: OrderedStudies)
ALTER TABLE OrderedStudies ADD CONSTRAINT FK_54
    FOREIGN KEY (StudyID)
    REFERENCES Studies (StudyID);

-- Reference: FK_55 (table: OrderedStudyMeetings)
ALTER TABLE OrderedStudyMeetings ADD CONSTRAINT FK_55
    FOREIGN KEY (ProductID)
    REFERENCES OrderDetails (ProductID);

-- Reference: FK_56 (table: OrderedStudyMeetings)
ALTER TABLE OrderedStudyMeetings ADD CONSTRAINT FK_56
    FOREIGN KEY (StudyMeetingID)
    REFERENCES StudyMeetings (StudyMeetingID);

-- Reference: FK_6 (table: TranslatorLanguages)
ALTER TABLE TranslatorLanguages ADD CONSTRAINT FK_6
    FOREIGN KEY (LanguageID)
    REFERENCES Languages (LanguageID);

-- Reference: FK_7 (table: Webinars)
ALTER TABLE Webinars ADD CONSTRAINT FK_7
    FOREIGN KEY (LecturerID)
    REFERENCES Employees (EmployeeID)
    ON DELETE  SET NULL;

-- Reference: FK_8 (table: Webinars)
ALTER TABLE Webinars ADD CONSTRAINT FK_8
    FOREIGN KEY (TranslatorID)
    REFERENCES Translators (TranslatorID)
    ON DELETE  SET NULL;

-- Reference: FK_9 (table: Webinars)
ALTER TABLE Webinars ADD CONSTRAINT FK_9
    FOREIGN KEY (LanguageID)
    REFERENCES Languages (LanguageID)
    ON DELETE  CASCADE;

-- End of file.




-- Reference: FK_16 (table: CourseModules)
--ALTER TABLE CourseModules ADD CONSTRAINT FK_16
--    FOREIGN KEY (LecturerID)
--    REFERENCES Employees (EmployeeID)
--    ON DELETE  SET NULL;

-- Reference: FK_25 (table: Studies)
--ALTER TABLE Studies ADD CONSTRAINT FK_25
--    FOREIGN KEY (StudySupervisorID)
--    REFERENCES Employees (EmployeeID)
--    ON DELETE  SET NULL;

-- Reference: FK_27 (table: Subjects)
--ALTER TABLE Subjects ADD CONSTRAINT FK_27
--    FOREIGN KEY (SubjectSupervisorID)
--    REFERENCES Employees (EmployeeID)
--    ON DELETE  SET NULL;

-- Reference: FK_38 (table: StudyMeetings)
--ALTER TABLE StudyMeetings ADD CONSTRAINT FK_38
--    FOREIGN KEY (LecturerID)
--    REFERENCES Employees (EmployeeID)
--    ON DELETE  SET NULL;

-- Reference: FK_7 (table: Webinars)
--ALTER TABLE Webinars ADD CONSTRAINT FK_7
--    FOREIGN KEY (LecturerID)
--    REFERENCES Employees (EmployeeID)
--    ON DELETE  SET NULL;

--CONSTRAINT CHECK_15 CHECK (( StartDate >= GETDATE ( ) )), DROPPED




select * from EmployeeFunctions

INSERT INTO EmployeeFunctions (EmployeeFunctionID, EmployeeFunctionName)
VALUES 
(1, 'Lecturer'),
(2, 'Secretary')
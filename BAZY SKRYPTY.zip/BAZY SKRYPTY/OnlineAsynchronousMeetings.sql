INSERT INTO OnlineAsynchronousMeetings (StudyMeetingID, VideoLink)
VALUES 
(16, '<link>'),
(17, '<link>'),
(18, '<link>'),
(19, '<link>'),
(20, '<link>'),

(31, '<link>'),
(32, '<link>'),
(33, '<link>'),
(34, '<link>'),
(35, '<link>')